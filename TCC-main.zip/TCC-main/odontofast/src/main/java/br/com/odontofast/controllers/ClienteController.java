package br.com.odontofast.controllers;

import br.com.odontofast.models.Cliente;
import br.com.odontofast.models.Status;
import br.com.odontofast.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost") // Permite requisições do frontend hospedado em localhost
@RequestMapping("/cliente") // Define a rota para a coleção de clientes
public class ClienteController {

    @Autowired
    private ClienteService clienteService; // Injeção de dependência para o serviço de Cliente

    // Endpoint para adicionar um novo cliente
    @PostMapping
    public Cliente adicionarCliente(@RequestBody Cliente cliente) {
        cliente.setStatus(Status.ATIVO); // Define o status como ATIVO por padrão
        return clienteService.salvarCliente(cliente); // Chama o serviço para salvar o cliente
    }

    // Endpoint para listar todos os clientes
    @GetMapping
    public List<Cliente> listarClientes() {
        return clienteService.listarClientes(); // Chama o serviço para listar todos os clientes
    }

    // Endpoint para buscar um cliente por ID
    @GetMapping("/{id}")
    public Cliente buscarCliente(@PathVariable Long id) {
        return clienteService.buscarCliente(id); // Chama o serviço para buscar um cliente pelo ID
    }

    // Endpoint para alterar o status de um cliente
    @PutMapping("/{id}/status")
    public Cliente alterarStatusCliente(@PathVariable Long id, @RequestParam Status status) {
        return clienteService.alterarStatusCliente(id, status); // Chama o serviço para alterar o status
    }
}
