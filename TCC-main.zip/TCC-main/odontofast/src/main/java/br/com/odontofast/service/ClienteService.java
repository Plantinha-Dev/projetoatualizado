package br.com.odontofast.service;

import br.com.odontofast.models.Cliente;
import br.com.odontofast.models.Status;
import br.com.odontofast.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository; // Injeção de dependência do repositório de Cliente

    // Método para salvar um cliente
    public Cliente salvarCliente(Cliente cliente) {
        return clienteRepository.save(cliente); // Salva o cliente no banco de dados
    }

    // Método para listar todos os clientes
    public List<Cliente> listarClientes() {
        return clienteRepository.findAll(); // Retorna todos os clientes do banco de dados
    }

    // Método para buscar um cliente por ID
    public Cliente buscarCliente(Long id) {
        Optional<Cliente> cliente = clienteRepository.findById(id); // Busca o cliente pelo ID
        return cliente.orElse(null); // Retorna o cliente se encontrado, senão retorna null
    }

    // Método para alterar o status de um cliente
    public Cliente alterarStatusCliente(Long id, Status status) {
        Optional<Cliente> clienteOpt = clienteRepository.findById(id); // Busca o cliente pelo ID
        if (clienteOpt.isPresent()) {
            Cliente cliente = clienteOpt.get();
            cliente.setStatus(status); // Atualiza o status do cliente
            return clienteRepository.save(cliente); // Salva as alterações no banco de dados
        }
        return null; // Retorna null se o cliente não for encontrado
    }
}
