package br.com.odontofast.service;

import br.com.odontofast.models.Usuario;
import br.com.odontofast.models.Status;
import br.com.odontofast.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository; // Injeção de dependência do repositório

    // Método para salvar um recepcionista
    public Usuario salvarUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario); // Salva o recepcionista no banco
    }

    // Método para listar todos os recepcionistas
    public List<Usuario> listarUsuario() {
        return usuarioRepository.findAll(); // Retorna todos os recepcionistas do banco
    }

    // Método para buscar um recepcionista por ID
    public Usuario buscarUsuario(Long id) {
        Optional<Usuario> usuario = usuarioRepository.findById(id); // Busca pelo ID
        return usuario.orElse(null); // Retorna o recepcionista ou null se não encontrado
    }

    // Método para alterar o status de um recepcionista
    public Usuario alterarStatusUsuario(Long id, Status status) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findById(id); // Busca o recepcionista
        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            usuario.setStatus(status); // Atualiza o status
            return usuarioRepository.save(usuario); // Salva as alterações no banco
        }
        return null; // Retorna null caso o recepcionista não seja encontrado
    }
}
