package br.com.odontofast.controllers;

import br.com.odontofast.models.Usuario;
import br.com.odontofast.models.Status;
import br.com.odontofast.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost") // Permite requisições do frontend hospedado em localhost
@RequestMapping("/Usuario") // Definindo a rota padrão para a entidade Recepcionista
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService; // Injeção de dependência para o serviço

    // Endpoint para adicionar um novo recepcionista
    @PostMapping
    public Usuario adicionarUsuario(@RequestBody Usuario usuario) {
        usuario.setStatus(Status.ATIVO); // Define o status como ATIVO por padrão
        return usuarioService.salvarUsuario(usuario); // Chama o serviço para salvar
    }

    // Endpoint para listar todos os recepcionistas
    @GetMapping
    public List<Usuario> listarUsuario() {
        return usuarioService.listarUsuario(); // Chama o serviço para listar todos os recepcionistas
    }

    // Endpoint para buscar um recepcionista pelo ID
    @GetMapping("/{id}")
    public Usuario buscarUsuario(@PathVariable Long id) {
        return usuarioService.buscarUsuario(id); // Chama o serviço para buscar pelo ID
    }

    // Endpoint para alterar o status de um recepcionista
    @PutMapping("/{id}/status")
    public Usuario alterarStatusUsuario(@PathVariable Long id, @RequestParam Status status) {
        return usuarioService.alterarStatusUsuario(id, status); // Chama o serviço para alterar o status
    }
}
