package br.com.odontofast.models;

public enum Status {
    ATIVO,
    INATIVO
}
