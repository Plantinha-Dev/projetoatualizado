package br.com.odontofast.controllers;

import br.com.odontofast.models.Associado;
import br.com.odontofast.models.Status;
import br.com.odontofast.service.AssociadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost") // Permite requisições do frontend hospedado em localhost
@RequestMapping("/associados") // Define a rota para a coleção de associados
public class AssociadoController {

    @Autowired
    private AssociadoService associadoService; // Injeção de dependência do serviço de Associado

    // Endpoint para adicionar um novo associado
    @PostMapping
    public ResponseEntity<Associado> adicionarAssociado(@RequestBody Associado associado) {
        // Definir o status como ATIVO por padrão
        if (associado.getStatus() == null) {
            associado.setStatus(Status.ATIVO);  // Se o status não for passado, define como ATIVO
        }

        // Salva o associado no banco
        Associado salvo = associadoService.salvarAssociado(associado);

        // Retorna a resposta com status HTTP 201 Created e o corpo da resposta com o objeto 'salvo'
        return ResponseEntity.status(HttpStatus.CREATED).body(salvo);
    }

    // Endpoint para listar todos os associados
    @GetMapping
    public List<Associado> listarAssociados() {
        return associadoService.listarAssociados(); // Retorna todos os associados
    }

    // Endpoint para buscar um associado por ID
    @GetMapping("/{id}")
    public ResponseEntity<Associado> buscarAssociado(@PathVariable Long id) {
        Associado associado = associadoService.buscarAssociado(id);
        if (associado != null) {
            return ResponseEntity.ok(associado); // Retorna o associado encontrado
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); // Caso não encontrado
        }
    }

    // Endpoint para alterar o status de um associado
    @PutMapping("/{id}/status")
    public ResponseEntity<Associado> alterarStatusAssociado(@PathVariable Long id, @RequestParam Status status) {
        Associado associadoAlterado = associadoService.alterarStatusAssociado(id, status);

        if (associadoAlterado != null) {
            return ResponseEntity.ok(associadoAlterado);  // Retorna o associado com o status alterado
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();  // Caso não encontrado
        }
    }
}
