package br.com.odontofast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class OdontofastApplication {

	public static void main(String[] args) {
		SpringApplication.run(OdontofastApplication.class, args); // Inicia a aplicação Spring Boot
	}
}
