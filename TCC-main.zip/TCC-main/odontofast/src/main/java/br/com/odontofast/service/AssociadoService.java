package br.com.odontofast.service;


import br.com.odontofast.models.Associado;
import br.com.odontofast.models.Status;
import br.com.odontofast.repositories.AssociadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AssociadoService {

    @Autowired
    private AssociadoRepository associadoRepository; // Injeção de dependência do repositório de Associado

    // Método para salvar um associado
    public Associado salvarAssociado(Associado associado) {
        return associadoRepository.save(associado); // Salva o associado no banco de dados
    }

    // Método para listar todos os associados
    public List<Associado> listarAssociados() {
        return associadoRepository.findAll(); // Retorna todos os associados do banco de dados
    }

    // Método para buscar um associado por ID
    public Associado buscarAssociado(Long id) {
        Optional<Associado> associado = associadoRepository.findById(id); // Busca o associado pelo ID
        return associado.orElse(null); // Retorna o associado se encontrado, senão retorna null
    }

    // Método para alterar o status de um associado
    public Associado alterarStatusAssociado(Long id, Status status) {
        Optional<Associado> associadoOpt = associadoRepository.findById(id); // Busca o associado pelo ID
        if (associadoOpt.isPresent()) {
            Associado associado = associadoOpt.get();
            associado.setStatus(status); // Atualiza o status do associado
            return associadoRepository.save(associado); // Salva as alterações no banco de dados
        }
        return null; // Retorna null se o associado não for encontrado
    }
}


